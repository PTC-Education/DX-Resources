// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

console.log($scope.app);

$scope.Snap = function() {
  console.log('hello world');
  var raw = JSON.stringify({"InputName":$scope.view.wdg.Username.text,
                            "InputImage":$scope.view.wdg.Camera.image});
  var requestOptions = {
    method: 'POST',
    headers: {
      'appKey': '<TW app key here>',
      'Content-Type': 'application/json'
    },
    body: raw
  };
  fetch("https://pp-2101111403aw.portal.ptc.io/Thingworx/Things/PerseveranceNotebook/Services/AddImage", requestOptions)
    .then(response => response.text())
    .then(result => console.log(result))
    .catch(error => console.log('error', error));

}

var ImgData;

$scope.Show = function () {
  console.log('hello');	
  var myHeaders = {'appKey': '<TW app key here>',
    'accept': 'application/json',
    'Content-Type':'application/json'}

    var raw = JSON.stringify({"searchExpression":$scope.view.wdg.Username.text});

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: raw
    };

    fetch("https://pp-2101111403aw.portal.ptc.io/Thingworx/Things/PerseveranceNotebook/Services/SearchDataTableEntries", requestOptions)
    .then(response => response.json())
    .then(function(json) {ImgData = json.rows;
                         $scope.view.wdg.ImageNumber.max = ImgData.length - 1;
                         $scope.view.wdg.ImageNumber.value = 0;
                         })
}

$scope.$watchGroup(['view.wdg.ImageNumber.value','view.wdg.ShowImages.value'],function() {
  $scope.view.wdg.Image.imgsrc = 'data:image/png;base64,'+ImgData[$scope.view.wdg.ImageNumber.value].Image;
  $scope.view.wdg.StudentName.text = "Username: "+ImgData[$scope.view.wdg.ImageNumber.value].StudentName;
  var Num = Number($scope.view.wdg.ImageNumber.value)+1;
  $scope.view.wdg.NumberOfImage.text = "Image #"+Num+" of "+ImgData.length;
  
});